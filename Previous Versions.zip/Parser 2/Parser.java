

import java.util.ArrayList;

public class Parser {

	private ArrayList<Token> tokenList = new ArrayList<Token>();
	private int i = 0;
	
	public Parser (ArrayList<Token> inTokenList) {
		tokenList = inTokenList;
	}
	
	
	/*
	 * Method to prase the token list
	 * returns the head of the AST
	 */
	public Node parse() throws Exception {
		return statements();
	}
	
	// finds all the statements in a line and creates nodes for them
	private Node statements() throws Exception{
		Node node = null;
		ArrayList<Node> nodeList = new ArrayList<Node>(); 
		do { // while there are still nodes to create statements
			node = statement(); // get statement
			if(node != null) // if its not null add it to the list
				nodeList.add(node);
			
			
		}while(node != null);
		
		Node nodeArray[] = new Node[nodeList.size()]; // convert the arraylist to an array (arrayList.toArray() returns an object for some reason)
		for(int i = 0; i < nodeList.size(); i++)
			nodeArray[i] = nodeList.get(i);
		
		StatementsNode returnNode = new StatementsNode(nodeArray);
		return returnNode;
	}
	
	/*
	 * gets a statement, if there is no statement returns null
	 */
	private Node statement() throws Exception{
		Node output = null; // node to be returned

		// find if theres a variable followed by an equals
		if((matchAndPeek(Token.State.IDENTIFIER)) && (matchAndPeek(Token.State.EQUALS, 1))) {
			output = assignment();
		}
		// find if there's a print statemnet
		else if(matchAndRemove(Token.State.PRINT) != null) {
			output = printStatement(printList());
		}
		// if there is no print or identifier it must be an expression
		else
			output = expression();
		
		return output;
	}
	
	// gathers comma seperated expressions and returns a list
	private ArrayList<Node> printList() throws Exception{
		ArrayList<Node> printArray = new ArrayList<Node>();
		
		do {
			printArray.add(expression());
		}while(matchAndRemove(Token.State.COMMA) != null);
		
		return printArray;
	}
	
	// takes a list of expressions and makes a print list
	private Node printStatement(ArrayList<Node> inStatement) throws Exception{
		
		PrintNode returnNode = new PrintNode(inStatement);
		
		return returnNode;
	}
	
	// creates a variable node with the proper value and name
	private Node assignment() throws Exception{
		
		VariableNode varNode = new VariableNode(matchAndRemove(Token.State.IDENTIFIER).getValue()); // get the name of the variable
		//System.out.println("VarNode = " +varNode.toString());
		
		if(matchAndRemove(Token.State.EQUALS) == null) // dont really need the token for anything
			throw new Exception("The equals sign isnt here even though the if before should've confirmed its location idk.");
		
		AssignmentNode output = new AssignmentNode(varNode, expression()); // get the value of the variable
		
		return output;
	}
	
	
	
	private Node expression() throws Exception {
		
		Node leftNode;
		Node rightNode;
		//boolean foundOperator = true;

		leftNode = term(); // sets the left Node as a term
		
		
		Token sign = matchAndRemove(Token.State.PLUS); // if the next token is a +
		if(sign == null)
			sign = matchAndRemove(Token.State.MINUS); // if the next token is a -
		if(sign != null) {
			rightNode = term(); // if there was a + or - that means there should be another term in the Expression
			MathOpNode expressionOperation = new MathOpNode(leftNode, convert(sign.getState()), rightNode); // create new MathOpNode with the left, right, and operation nodes
			
			while((sign !=null) && (matchAndRemove(Token.State.RPARAN) == null)) { // Handles successive additive operations (1 + 1 + 1 + 1)
				sign = null;
				sign = matchAndRemove(Token.State.PLUS); // if the next token is a plus
				if(sign == null)
					sign = matchAndRemove(Token.State.MINUS); // if the next token in a minus
				if(sign != null) {
					expressionOperation = new MathOpNode(expressionOperation, convert(sign.getState()), term()); // if the next token is an operation, create a new MathNode which will expand the previous mathNode
				}
				
			}
			
			return expressionOperation; // return the completed additive block
		}
		


		return leftNode; // if there is only a number and no +- operation
		
	}
	
	private Node term() throws Exception {
		Node leftNode = factor(); // get the left Node
		Node rightNode;
		
		Token sign = matchAndRemove(Token.State.TIMES); // if the next token is a *
		if(sign == null)
			sign = matchAndRemove(Token.State.DIVIDE); // if the next token is a /
		if(sign != null) {
			rightNode = factor(); // if there is a * or / there must be another factor
			MathOpNode termOperation = new MathOpNode(leftNode, convert(sign.getState()), rightNode); // create a MathOpNode with the two factors and the operation
			
			while((sign !=null) && (matchAndRemove(Token.State.RPARAN) == null)) { // whle for successive operations
				sign = null;
				sign = matchAndRemove(Token.State.TIMES); // find *
				if(sign == null)
					sign = matchAndRemove(Token.State.DIVIDE); // find /
				if(sign != null) {
					termOperation = new MathOpNode(termOperation, convert(sign.getState()), factor()); // create a chain of multiplication or division ( 1 * 1 * 1 * 1 )
				}
				
			}
			
			return termOperation; // return completed multiplicative statement
		}
		
		
		
		return leftNode; // if there is no operation just return the factor
	}
	
	// returns a FloatNode or IntegerNode or the value returned from EXPRESSION
	private Node factor() throws Exception {
		
		
		Node factorNode = null; // node must be a number or expression
		
		Token factor = matchAndRemove(Token.State.LPARAN); // check for left paran
		if(factor != null)
			factorNode = expression(); // if there is one call expression
		else if(matchAndPeek(Token.State.NUMBER)) { // if theres no left paran it must be a number
			factor = matchAndRemove(Token.State.NUMBER); // find the number
			if(factor.getValue().contains(".")) // if it contains a . its a float, the lexer should assure we have correct form (no 1.2.3 will appear)
				factorNode = new FloatNode(Float.parseFloat(factor.getValue())); // assign the float value
			else
				factorNode = new IntegerNode(Integer.parseInt(factor.getValue())); // assign the interger value
		}
		else if((matchAndPeek(Token.State.IDENTIFIER)) && (!matchAndPeek(Token.State.EQUALS, 1))) {
			factorNode = new VariableNode(matchAndRemove(Token.State.IDENTIFIER).toString());
		}
		return factorNode; // return the node
	}
	
	
	/*
	 * finds the next token, if its what we request it will return and remove it, else it returns null
	 */
	private Token matchAndRemove(Token.State inState) throws Exception {
		if(tokenList.get(0).getState() == inState) { // see if the next token is the token we want
			Token lexeme = tokenList.get(0); // if so then grab and return that
			tokenList.remove(0);
			return lexeme;
		}
			
		else // no token returns null
			return null;
	}
	
	private boolean matchAndPeek(Token.State inState) throws Exception {
		if(tokenList.get(0).getState() == inState) { // see if the next token is the token we want
			return true;
		}
		else // no token returns null
			return false;
	}
	
	private boolean matchAndPeek(Token.State inState, int offset) throws Exception {
		if(tokenList.get(0+offset).getState() == inState) { // see if the next token is the token we want
			return true;
		}
		else // no token returns null
			return false;
	}
	
	//private PrintNode printStatement(String inString) {
	//	return new PrintNode(inString);
	//}
	
	/*
	 * converts a Token State Enum to a MathOpNode Operation Enum
	 */
	private MathOpNode.Operation convert(Token.State inState) {
		switch(inState) {
		case PLUS: return MathOpNode.Operation.ADD;
		case MINUS: return MathOpNode.Operation.SUBTRACT;
		case TIMES: return MathOpNode.Operation.MULTIPLY;
		case DIVIDE: return MathOpNode.Operation.DIVIDE;
		default: return null;
		}
	}
	
}
