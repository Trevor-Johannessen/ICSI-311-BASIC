

public class VariableNode extends Node{

	private String name;
	private String value;
	
	public VariableNode(String inName) {
		name = inName;
		value = null;
	}
	
	public String getName() {
		return name;
	}
	
	public String getValue() {
		return value;
	}
	
	public String toString() {
		return name;
	}
}
