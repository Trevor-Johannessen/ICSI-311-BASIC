
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * PROGRAM FUNCTION:
 * 	
 * Take in ONE argument
 * this argument will be treated as a file (arg.txt)
 * 
 *
 */
public class Basic {

	
	public static void main(String[] argv) throws Exception
	{
		// if there are more or less than 1 argument
		if(argv.length != 1)
		{
			System.out.println("Invalid Input, there are " +argv.length +" arguments, there must only be 1.");
		
		}
		// if there is only one argument
		else
		{
			
			String fileName = get_file_name(argv[0]);						// gets filename from args
			Path test = Paths.get(fileName); 								// creates path for readAllLines
			List<String> strList = Files.readAllLines(test); 				// read all the lines from the file
			
			Lexer.knownWords.put("PRINT", Token.State.PRINT);
			ArrayList<Token> tokenList = new ArrayList<Token>(); 			// list for each line from lex

			
			for(int i = 0; i < strList.size(); i++) 						// for each line in the file
			{
				boolean validList = true;
				try {
				tokenList = Lexer.lex(strList.get(i)); 						// call the Lex function to parse the line
				}catch(java.lang.Exception e) {
					
					System.out.println(e);
					validList = false;
				}
				
				
				
				if(validList)												// if the list is made of valid characters
				{
					for(int j = 0; j < tokenList.size(); j++)				// for each token returned print out its state
						System.out.print(tokenList.get(j).toString() +" ");
					System.out.println();
					
					System.out.println("PARSER TIME");						// its parser time
					System.out.println();
					
					Parser parser = new Parser(tokenList);
					System.out.println(parser.parse().toString());
					 
				}
				
			}

				
				
			
			
			
			
			
			
			
		}
		
		
	}
	
	/**
	 * Checks if file has .txt file extension, if not adds one
	 * @param input inputed file name
	 * @return formatted file name
	 */
	public static String get_file_name(String input)
	{
		if((input.length() > 4) && (input.substring(input.length()-4).equals(".txt")))
			return input;
		return input.concat(".txt");
	}
	
}
