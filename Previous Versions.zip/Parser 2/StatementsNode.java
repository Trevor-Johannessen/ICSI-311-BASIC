

public class StatementsNode extends StatementNode{

	private Node[] nodeArr;
	
	public StatementsNode(Node[] inNodeArr) {
		nodeArr = inNodeArr;
	}
	
	public Node getNode(int i) {
		return nodeArr[i];
	}
	
	public Node[] getNodeArray() {
		return nodeArr;
	}
	
	public String toString() {
		String str = "";
		for(int i = 0; i < nodeArr.length; i++) {
			str = str +nodeArr[i].toString() +" ";
		}
		return str;
	}
}
