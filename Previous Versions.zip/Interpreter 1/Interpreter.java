

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Stack;

public class Interpreter {

	public static HashMap<String, Integer> varInteger = new HashMap<String, Integer>();
	public static HashMap<String, Float> varFloat = new HashMap<String, Float>();
	public static HashMap<String, String> varString = new HashMap<String, String>();
	
	public static HashMap<String, Node> labels = new HashMap<String, Node>();
	
	public static ArrayList<Node> dataInfo = new ArrayList<Node>();
	
	public static StatementsNode statements;
	
	public static void interpret(StatementsNode inStatements) {
		
		statements = inStatements;
		statements.read();
		
		initalize();
		
		
		
		
	} // end of interpreter (main)
	
	// initalize the interpreters StatementsNode
	public static void initalize() {
		swapLabels(); // swap the labels
		matchLoops(); // match forloops with their Next counterparts
		inputData(); // store inputted data
		linkStatements(); // link all statements in a linked list
		
		for(int i = 0; i < dataInfo.size(); i++)
			System.out.println(dataInfo.get(i).getValue());
	}
	
	// notes labels and replaces them with statements in the list
	public static void swapLabels() {
		for(int i = 0; i < statements.getNodeArray().size(); i++) { // for each node in the statements array
			//System.out.println("current Node: " +statements.getNode(i).toString());
			if(statements.getNode(i).getClass().equals(LabeledStatementNode.class)) { // if the node is an instance of the LabeledStatementNode class
				//System.out.println("IS LABELED STATEMENT");
				LabeledStatementNode labeled = (LabeledStatementNode) statements.getNode(i); // convert the Node (generic) to labeled statement node
				labels.put(labeled.getLabel(), labeled.getNode()); // add the node to the hashmap
				statements.setNode(i, labeled.getNode()); // add the unlabeled statement back into the list
			}
		}
	}
	
	// matches forloops with their NEXT counterparts
	public static void matchLoops() {
		Stack<ForNode> forNodeStack = new Stack<ForNode>(); // stack to match forloops
		
		for(int i = 0; i < statements.getNodeArray().size(); i++) { // for each node in the statements array
			
			//System.out.println("current Node: " +statements.getNode(i).toString());
			if(statements.getNode(i).getClass().equals(ForNode.class)) { // if the node is an instance of the ForNode class
				//System.out.println("IS FOR NODE");
				forNodeStack.push((ForNode) statements.getNode(i)); // store the forNode so we can use it later
			}
			else if(statements.getNode(i).getClass().equals(NextNode.class)){ // if the node is an instance of the NextNode class
				//System.out.println("IS NEXT NODE");
				NextNode next = (NextNode) statements.getNode(i); // convert the Node (generic) to NextStatement node
				next.setParent(forNodeStack.peek()); // set the parent of the Next Node as the top forLoop on the stack
				forNodeStack.pop().setAfter(statements.getNode(i+1)); // set the ForNodes after statement
			}
			//System.out.println("Stack Size: " +forNodeStack.size());
		}
		
	}
	
	// stores all inputted data into the public variables
	public static void inputData() {
		//System.out.println("length = " +statements.getNodeArray().size());
		for(int i = 0; i < statements.getNodeArray().size(); i++) { // for each node in the statements array
			System.out.println("current Node: " +statements.getNode(i).toString());
			if(statements.getNode(i).getClass().equals(DataNode.class)) { // if the node is an instance of the DataNode class
				System.out.println("IS DATA NODE");
				DataNode data = (DataNode) statements.getNode(i);// convert the Node (generic) to DataStatement node
				
				for(Node current : data.getList()) // for all data in the dataNode
					dataInfo.add(current); // add each piece of data
				statements.getNodeArray().remove(i); // remove the DataNode
				i-=1; // backtrack one since the array will have moved back due to .remove()
			}
		}
	}
	
	// sets the next reference to the next statement in the list
	public static void linkStatements() {

		for(int i = 0; i < statements.getNodeArray().size()-1; i++) { // if its not the end of the list
			statements.getNode(i).setNext(statements.getNode(i+1)); // set the reference of each node to its successor
		}
		// print out each statements Next Node (as an array)
		/*
		for(int i = 0; i < statements.getSize(); i++) 
			System.out.println(i +": " +(statements.getNode(i).getNext() == null));
		*/
		
		// reads each node as a linked list
		//statements.readAsLinkedList();
	}

} // end of class
