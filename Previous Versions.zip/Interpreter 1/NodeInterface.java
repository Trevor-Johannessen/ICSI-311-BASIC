

public interface NodeInterface {
	public void accept(VisitorInterface visitor);
}
