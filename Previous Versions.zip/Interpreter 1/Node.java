

public abstract class Node implements NodeInterface{

	/*
	 * Very long class, may consume your entire day.
	 */
	public abstract String toString();
	
	public abstract Object getValue();
}
