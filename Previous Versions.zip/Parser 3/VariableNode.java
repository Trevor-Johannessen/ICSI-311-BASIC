

public class VariableNode extends Node{

	private String name;
	
	public VariableNode(String inName) {
		name = inName;
	}
	
	public String getName() {
		return name;
	}
	
	public String getValue() {
		return name;
	}
	
	public String toString() {
		return name;
	}
}
