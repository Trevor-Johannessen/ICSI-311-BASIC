

public class MathOpNode extends Node{

	public enum Operation
	{
		ADD, SUBTRACT, MULTIPLY, DIVIDE;
	}
	
	private Operation operation;
	private Node nextNode;
	private Node lastNode;
	
	public MathOpNode(Node inLastNode, Operation inOp, Node inNextNode)
	{
		operation = inOp;
		nextNode = inNextNode;
		lastNode = inLastNode;
	}
	
	public Operation getOperation() {
		return operation;
	}

	@Override
	public String toString() {
		String str = "MathNode(";
		str= str +lastNode.toString() +" ";
		str = str +operation.toString() +" ";
		str = str +nextNode.toString() +")";
		return str;
	}

	public Object getValue() {
		return this.toString();
	}
	
	
}
