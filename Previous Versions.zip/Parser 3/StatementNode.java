

public class StatementNode extends Node{
	
	
	
	public StatementNode() {
		
	}

	@Override
	public String toString() {
		return null ;
	}

	public Object getValue() {
		return null;
	}
}
