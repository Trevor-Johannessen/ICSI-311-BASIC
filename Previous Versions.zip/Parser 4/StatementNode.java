

public class StatementNode extends Node{
	


	
	public String toString() {
		return null;
	}

	public Object getValue() {
		return null;
	}
}
