

public class NextNode extends StatementNode{

	private VariableNode var;
	
	public NextNode(VariableNode inVar /*like the metal*/) {
		var = inVar;
	}
	
	public VariableNode getValue() {
		return var;
	}
	
	public String toString() {
		return "NEXT(" +var.toString() +")";
	}
}
