

public class GosubNode extends StatementNode{
	private Token identifier;
	
	public GosubNode(Token inIdentifier) {
		identifier = inIdentifier;
	}
	
	public Token getValue() {
		return identifier;
	}
	
	
	public String toString() {
		return "GOSUB(" +identifier.getValue() +")";
	}
	
	
}
