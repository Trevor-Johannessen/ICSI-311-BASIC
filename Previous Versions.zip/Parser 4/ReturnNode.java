

public class ReturnNode extends StatementNode{

	
	public ReturnNode() {
		
	}
	
	public String toString() {
		return "RETURN";
	}
	
	public String getValue() {
		return "RETURN";
	}
}
